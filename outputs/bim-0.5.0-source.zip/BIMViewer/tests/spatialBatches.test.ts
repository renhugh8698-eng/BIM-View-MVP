import { describe, expect, it } from 'vitest';
import { BoxGeometry, Mesh, MeshStandardMaterial, Vector3, Box3 } from 'three';
import { SpatialBatches } from '../src/lib/spatialBatches';
import { defaultSettings, parseSettings } from '../src/lib/inspection';

function fixture() {
  const material = new MeshStandardMaterial();
  const a = new Mesh(new BoxGeometry(),material), b = new Mesh(new BoxGeometry(),material);
  a.userData.bimId = 'a'; b.userData.bimId = 'b';
  a.position.x = 2; b.position.x = 2; a.updateMatrixWorld(true); b.updateMatrixWorld(true);
  return { a,b,material };
}
describe('spatial material batches', () => {
  it('merges compatible meshes without groups and preserves transformed bounds and source arrays', () => {
    const {a,b} = fixture(); const before = Array.from(b.geometry.attributes.position.array);
    const batches = new SpatialBatches([a,b],()=> 'wall');
    expect(batches.batches).toHaveLength(1); const merged = batches.batches[0].mesh;
    expect(merged.geometry.groups).toHaveLength(0); expect(merged.geometry.index?.count).toBe(72);
    const expected = new Box3().expandByObject(a).expandByObject(b);
    expect(merged.geometry.boundingBox!.max.distanceTo(expected.max)).toBeLessThan(1e-6);
    expect(Array.from(b.geometry.attributes.position.array)).toEqual(before);
    expect(batches.sources.has(a)).toBe(true); batches.dispose();
    expect(batches.root.children).toHaveLength(0);
  });
  it('compacts visibility without stale indices and restores hidden/isolated/selected components', () => {
    const {a,b} = fixture(); const batches = new SpatialBatches([a,b],()=> 'wall');
    const mesh = batches.batches[0].mesh;
    batches.update(source => source === b);
    expect(mesh.geometry.drawRange.count).toBe(36); expect(mesh.geometry.index!.getX(0)).toBe(b.geometry.index!.getX(0)+24);
    batches.update(()=>false); expect(mesh.visible).toBe(false); expect(mesh.geometry.drawRange.count).toBe(0);
    batches.update(()=>true); expect(mesh.visible).toBe(true); expect(mesh.geometry.drawRange.count).toBe(72);
    expect(mesh.geometry.index!.getX(0)).toBe(a.geometry.index!.getX(0)); batches.dispose();
  });
  it('keeps transparent, mirrored, different-category and different-material meshes separate', () => {
    const {a,b,material} = fixture(); material.transparent = true;
    expect(new SpatialBatches([a,b],()=> '').batches).toHaveLength(0);
    material.transparent = false; b.scale.x = -1; b.updateMatrixWorld(true);
    expect(new SpatialBatches([a,b],()=> '').batches).toHaveLength(0);
    b.scale.x = 1; b.updateMatrixWorld(true);
    expect(new SpatialBatches([a,b],m=>m.userData.bimId).batches).toHaveLength(0);
    b.material = material.clone(); expect(new SpatialBatches([a,b],()=> '').batches).toHaveLength(0);
  });
  it('does not combine distant blocks and obeys cache memory budget', () => {
    const {a,b} = fixture(); expect(new SpatialBatches([a,b],()=> '',0).batches).toHaveLength(0);
    b.position.copy(new Vector3(100,0,0)); b.updateMatrixWorld(true);
    expect(new SpatialBatches([a,b],()=> '').batches).toHaveLength(0);
  });
});
describe('navigation defaults', () => {
  it('disables inertia for new and legacy settings while enabling batching', () => {
    expect(defaultSettings.damping).toBe(false); expect(parseSettings('{}').damping).toBe(false);
    expect(parseSettings('{"damping":"true"}').damping).toBe(false); expect(defaultSettings.batching).toBe(true);
  });
  it('persists explicit inertia and original-renderer preferences', () => {
    const value = {...defaultSettings,damping:true,batching:false}; expect(parseSettings(JSON.stringify(value))).toEqual(value);
  });
});
