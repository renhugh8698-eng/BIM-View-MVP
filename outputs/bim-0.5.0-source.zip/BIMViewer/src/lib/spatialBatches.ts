import { Box3, Group, Mesh, Vector3, type BufferGeometry, type Material } from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

type Part = { source: Mesh; vertexOffset: number; count: number; visible: boolean };
type Batch = { mesh: Mesh; parts: Part[] };

// Original geometry stays authoritative for picking, measurements and the fallback renderer.
export class SpatialBatches {
  readonly root = new Group();
  readonly sources = new Set<Mesh>();
  readonly batches: Batch[] = [];
  bytes = 0;
  constructor(meshes: Mesh[], category: (mesh: Mesh) => string, maxBytes = 512 * 1048576) {
    const bounds = new Box3(), center = new Vector3();
    for (const mesh of meshes) bounds.expandByObject(mesh);
    const size = Math.max(...bounds.getSize(new Vector3()).toArray(), 1) / 6;
    const groups = new Map<string, Mesh[]>();
    for (const mesh of meshes) {
      const g = mesh.geometry, m = mesh.material;
      if (Array.isArray(m) || m.transparent || mesh.matrixWorld.determinant() <= 0 ||
        'isSkinnedMesh' in mesh || 'isInstancedMesh' in mesh || Object.keys(g.morphAttributes).length ||
        !g.index || g.drawRange.start !== 0 || g.drawRange.count !== Infinity ||
        !g.attributes.position || g.attributes.position.count > 250000) continue;
      if (!g.boundingBox) g.computeBoundingBox();
      g.boundingBox!.getCenter(center).applyMatrix4(mesh.matrixWorld).sub(bounds.min).divideScalar(size).floor();
      const layout = Object.entries(g.attributes).map(([name,a]) => `${name}:${a.itemSize}:${a.normalized}:${a.array.constructor.name}`).sort().join(',');
      const key = `${m.uuid}|${category(mesh)}|${center.toArray()}|${layout}`;
      const list = groups.get(key) ?? []; list.push(mesh); groups.set(key,list);
    }
    try {
      for (const group of groups.values()) {
        let chunk: Mesh[] = [], vertices = 0;
        for (const mesh of group) {
          const count = mesh.geometry.attributes.position.count;
          if (vertices + count > 250000) { this.add(chunk,maxBytes); chunk = []; vertices = 0; }
          chunk.push(mesh); vertices += count;
        }
        this.add(chunk,maxBytes);
      }
    } catch (error) { this.dispose(); throw error; }
  }
  private add(sources: Mesh[], maxBytes: number) {
    if (sources.length < 2) return;
    const estimate = sources.reduce((n,m) => n + m.geometry.index!.count * 4 + Object.values(m.geometry.attributes).reduce((s,a) => s + a.array.byteLength,0),0);
    if (this.bytes + estimate > maxBytes) return;
    const copies: BufferGeometry[] = [];
    let geometry: BufferGeometry | null = null;
    try {
      for (const source of sources) copies.push(source.geometry.clone().applyMatrix4(source.matrixWorld));
      geometry = mergeGeometries(copies,false);
    } finally { copies.forEach(g => g.dispose()); }
    if (!geometry) return;
    geometry.computeBoundingBox(); geometry.computeBoundingSphere();
    const mesh = new Mesh(geometry,sources[0].material as Material);
    const parts: Part[] = []; let vertexOffset = 0;
    for (const source of sources) {
      parts.push({source,vertexOffset,count:source.geometry.index!.count,visible:true});
      vertexOffset += source.geometry.attributes.position.count; this.sources.add(source);
    }
    this.bytes += geometry.index!.array.byteLength + Object.values(geometry.attributes).reduce((s,a) => s+a.array.byteLength,0);
    this.batches.push({mesh,parts}); this.root.add(mesh);
  }
  update(visible: (mesh: Mesh) => boolean) {
    for (const {mesh,parts} of this.batches) {
      let changed = false;
      for (const part of parts) { const next = visible(part.source); if (next !== part.visible) changed = true; part.visible = next; }
      if (!changed) continue;
      const index = mesh.geometry.index!; let cursor = 0;
      for (const part of parts) {
        if (!part.visible) continue;
        const source = part.source.geometry.index!;
        for (let i=0;i<part.count;i++) index.setX(cursor++,source.getX(i)+part.vertexOffset);
      }
      mesh.geometry.setDrawRange(0,cursor); mesh.visible = cursor > 0;
      index.needsUpdate = true;
    }
  }
  dispose() {
    for (const batch of this.batches) batch.mesh.geometry.dispose();
    this.root.clear(); this.batches.length = 0; this.sources.clear(); this.bytes = 0;
  }
}
