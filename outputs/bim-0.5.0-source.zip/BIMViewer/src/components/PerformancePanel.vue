<script setup lang="ts">
import { Download, RotateCcw, X } from 'lucide-vue-next';
import type { PerformanceSnapshot } from '../lib/performance';
defineProps<{ stats: PerformanceSnapshot | null; continuous: boolean; elements: number }>();
defineEmits<{ close: []; reset: []; download: []; continuous: [value: boolean] }>();
const n = (value: number) => Math.round(value).toLocaleString();
const ms = (value: number | null) => value === null ? '--' : `${value.toFixed(1)} ms`;
const mib = (value: number | null) => value === null ? '--' : `${(value / 1048576).toFixed(1)} MiB`;
</script>
<template>
  <section class="inspection-panel performance-panel" aria-label="性能监控">
    <header>性能监控<button class="icon-button" title="关闭性能监控" @click="$emit('close')"><X :size="16" /></button></header>
    <div class="performance-actions">
      <label><input type="checkbox" :checked="continuous" @change="$emit('continuous', ($event.target as HTMLInputElement).checked)" />持续渲染</label>
      <button class="icon-button" title="重置采样" @click="$emit('reset')"><RotateCcw :size="16" /></button>
      <button class="icon-button" title="导出性能报告" :disabled="!stats" @click="$emit('download')"><Download :size="16" /></button>
    </div>
    <template v-if="stats">
      <div class="performance-summary"><strong>{{ stats.timing.idle ? '--' : stats.timing.fps?.toFixed(1) ?? '--' }} <small>FPS</small></strong><span>{{ stats.timing.idle ? '静止 · 按需渲染' : continuous ? '持续采样' : '交互采样' }}</span></div>
      <div class="frame-chart" aria-label="最近连续帧耗时" title="最近 40 个连续渲染帧的间隔，柱高上限 100ms">
        <i v-for="(value,index) in stats.timing.history" :key="index" :style="{ height: `${Math.max(2, Math.min(100,value))}%`, background: value > 50 ? '#cf644b' : value > 25 ? '#ba973d' : '#2a958d' }" />
      </div>
      <dl class="performance-metrics">
        <dt title="累计主循环绘制次数；静止时应保持不变">累计渲染帧</dt><dd>{{ n(stats.renderedFrames) }}</dd>
        <dt>最近交互 FPS</dt><dd>{{ stats.timing.fps?.toFixed(1) ?? '--' }}</dd>
        <dt title="最近最多 120 个连续帧间隔；跳过静止等待时间">平均 / P95 帧间隔</dt><dd>{{ ms(stats.timing.frameMs) }} / {{ ms(stats.timing.p95Ms) }}</dd>
        <dt>采样数 / 超过 50ms</dt><dd>{{ stats.timing.samples }} / {{ stats.timing.slowFrames }}</dd>
        <dt title="renderer.render 的 CPU 调用耗时，不等于 GPU 执行耗时">CPU 渲染提交</dt><dd>{{ ms(stats.timing.cpuMs) }}</dd>
        <dt>GPU 耗时</dt><dd>未采集</dd>
        <dt>最近拾取</dt><dd>{{ ms(stats.pickMs) }}</dd>
        <dt>最近材质更新</dt><dd>{{ ms(stats.appearanceMs) }}</dd>
        <dt title="GLTFLoader 开始至场景准备完成，不包含文件选择及 JSON 校验">GLB 加载与准备</dt><dd>{{ ms(stats.loadMs) }}</dd>
      </dl>
      <h3>最近一帧</h3>
      <dl class="performance-metrics">
        <dt>Draw Calls</dt><dd>{{ n(stats.calls) }}</dd>
        <dt title="提交给 GPU 的三角形，包含多遍透明绘制；不是最终屏幕可见像素">绘制三角形</dt><dd>{{ n(stats.triangles) }}</dd>
        <dt>绘制线段 / 点</dt><dd>{{ n(stats.lines) }} / {{ n(stats.points) }}</dd>
        <dt>缓冲分辨率</dt><dd>{{ stats.width }} × {{ stats.height }}</dd>
        <dt>像素比</dt><dd>{{ stats.pixelRatio.toFixed(2) }}</dd>
      </dl>
      <h3>模型与资源</h3>
      <dl class="performance-metrics">
        <dt>空间合批</dt><dd>{{ stats.optimization.enabled ? '启用' : '原始绘制' }}</dd>
        <dt>缓存合批数</dt><dd>{{ n(stats.optimization.batches) }}</dd>
        <dt>共享 / 选中材质</dt><dd>{{ n(stats.optimization.sharedMaterials) }} / {{ n(stats.optimization.selectedMaterials) }}</dd>
        <dt title="额外合并几何缓存；原始几何保留用于精确拾取和回退">合批数组增量</dt><dd>{{ mib(stats.optimization.cachedBytes) }}</dd>
        <dt>构件数</dt><dd>{{ n(elements) }}</dd>
        <dt>模型三角形总量</dt><dd>{{ n(stats.model.triangles) }}</dd>
        <dt>源网格 / 显示开启</dt><dd>{{ n(stats.model.meshes) }} / {{ n(stats.visibleMeshes) }}</dd>
        <dt>透明网格</dt><dd>{{ n(stats.transparentMeshes) }}</dd>
        <dt>实例化批次 / 实例数</dt><dd>{{ n(stats.model.instancedBatches) }} / {{ n(stats.model.instances) }}</dd>
        <dt>LOD 组 / 层级总数</dt><dd>{{ stats.model.lodGroups }} / {{ stats.model.lodLevels }}</dd>
        <dt>当前 LOD</dt><dd>{{ stats.activeLods }}</dd>
        <dt>独立几何 / 材质对象</dt><dd>{{ n(stats.model.uniqueGeometries) }} / {{ n(stats.model.materialObjects) }}</dd>
        <dt title="渲染器资源计数，包含网格、环境及辅助对象，不代表显存字节数">渲染器几何 / 纹理</dt><dd>{{ n(stats.geometries) }} / {{ n(stats.textures) }}</dd>
        <dt>Shader Programs</dt><dd>{{ n(stats.programs) }}</dd>
        <dt title="去重属性数组字节数估算，不包含纹理、JS 对象或 GPU 驱动开销">几何数组估算</dt><dd>{{ mib(stats.model.geometryBytes) }}</dd>
        <dt title="浏览器提供的 JS 堆估计；不是显存，也不只包含模型">JS 堆（浏览器估计）</dt><dd>{{ mib(stats.heapBytes) }}</dd>
      </dl>
    </template>
  </section>
</template>
