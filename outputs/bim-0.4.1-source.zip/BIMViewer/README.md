# BIMViewer

## 0.4.1 performance diagnostics

Open the bottom-toolbar performance monitor. Rotate/pan for interaction samples or enable continuous rendering for a fixed-view baseline. Reset samples and download a local JSON report from the panel. Closing the panel stops forced rendering. Diagnostics are opt-in; summary updates are limited to twice per second.

Metrics include FPS, mean/P95 frame intervals, slow frames, CPU render submission, last pick/material update, GLB preparation, renderer draw calls/triangles/resources, mesh/element counts, actual InstancedMesh batches/instances, actual LOD groups/levels, drawing-buffer size and estimated geometry-array/JS-heap memory. GPU duration is explicitly unavailable. Idle on-demand rendering is not reported as zero FPS. History retains at most 120 consecutive-render intervals; idle gaps are excluded. Changing continuous mode resets samples.

Submitted triangles include extra material passes and are not visible-pixel counts. Visibility-enabled meshes are not frustum/occlusion results. Geometry-array estimates and browser JS heap are not GPU VRAM measurements. GLB preparation excludes the earlier file/package-read stage and first GPU upload. LOD and instancing are reported, not introduced by this release.

Local development baseline: the 531,831,788-byte MEP package has 10,749 elements, 11,653 meshes, 11,992,909 model triangles and 59 source materials. At a 1280x654 drawing buffer, one fixed-view sample measured approximately 10.5 FPS, 94.9 ms mean / 122.1 ms P95, 11,777 draw calls, 12,005,557 submitted triangles, no instancing and no LOD. This is a machine/workload-dependent diagnostic baseline, not a hardware-independent benchmark. The runtime currently has 11,653 cloned material objects. Prioritize material reuse and spatial/material batching with preserved element mapping, then safe repeated-geometry instancing, geometric simplification/LOD and streaming chunks. Compression alone does not remove draw calls.

Verification: 30 tests passed with real-package and C# fixture paths enabled; TypeScript/Vite build passed (existing large-chunk warning). Both small and large local GLBs were inspected in-browser. Exporter remains 0.3.0; no DLL update.

## 0.4.0 inspection tools

- Canvas-first desktop layout with a bottom toolbar and initially closed side panels. Tree children mount only when a category is expanded; search expands matching branches.
- Distance: click two visible model surfaces. Results show millimeters and absolute XYZ differences. Angle: click three points; the second point is the vertex. Multiple results, pending-point undo, per-result removal and clear-all are supported.
- Measurements use glTF world meters (Y is vertical), not original Revit Z-up axes. Picks hit tessellated surfaces, without CAD endpoint snapping or survey-grade guarantees. Hidden and clipped geometry is excluded. Results are session-only and reset on model replacement; annotations remain visible until removed even if their owning geometry is hidden later.
- Free roaming uses Three.js FlyControls: WASD moves, mouse drag turns, R/F rises/descends, Esc exits. Speed is meters/second. Focus the canvas to move; leaving canvas focus or switching windows stops input. No collision, gravity or ground following is implemented.
- PNG export captures the current model view and measurement labels, not the surrounding app panels. Fullscreen is a browser API feature; opening a sidebar exits fullscreen to reveal that sidebar.
- Display mode, edge/grid toggles, exposure and roam speed persist locally under `bim-viewer-settings-v1`. Storage errors and invalid values safely fall back. Reset defaults is available in Settings; model files and measurement data are not persisted.
- The 0.3.0 exporter and material lighting are unchanged. No DLL replacement is needed for this frontend release.

Verification: 23 Vitest tests with actual-package and C# fixture paths enabled, TypeScript/Vite production build, browser distance/90-degree angle/undo-delete controls, keyboard roam motion, downloaded PNG, reload persistence, fullscreen/sidebar transitions, and desktop/mobile rendering. Actual model: 10,749 elements, 59 materials, 11,992,909 triangles. This is functional validation, not a guaranteed frame-rate benchmark. Heavy edge generation or large expanded categories can still be expensive.

Deferred: exact minimum-clearance/volume/area measurement, collision-aware walking, cut-face capping, saved annotations/viewpoints, sharing and cloud storage. Existing large-bundle and dependency-audit warnings remain; this is a local MVP.

## 0.3.0 workbench

The viewer now includes collapsible side panels, tree search, original-material/category/white/x-ray display modes, a category legend, standard OrbitControls navigation, selection focus, top/front/right views, optional edge lines and ground grid, exposure adjustment, and an axis-aligned clipping plane. Cut surfaces are not capped. Category colors are UI overrides, not recovered Revit materials. The renderer preserves original colors and opacity when returning to material mode.

The model uses the full remaining workspace; mobile retains model/tree/property tabs. Frames are drawn on scene or camera changes rather than redrawing an idle model continuously. Edge geometry is created lazily and may add cost on large models.

UI references: [minBIM](https://www.minbim.com/examples/viewer/id/kL8xP_2mNq.html) for a canvas-first layout and compact tools, and [BIMFACE](https://api.bimface.com/preview/32704cbf?viewid=1369) for inspectable material shading, direction views and clipping. No proprietary SDK or source is incorporated.


Vue 3 + TypeScript + Three.js viewer for the BIM MVP package exported by `BIMExporter`.

## Features

- Open one self-contained BIMExporter 0.2.0 GLB, or a legacy GLB/JSON pair
- Read current camelCase and legacy PascalCase BIMExporter metadata
- Validate GLB headers and matching element IDs before committing a new package
- Orbit/zoom camera controls
- Pick model elements
- Show properties
- Browse category-based model tree
- Hide/show elements
- Isolate selected element

## Commands

```powershell
npm install
npm run test
npm run build
npm run dev
```

Open the local Vite URL and choose the new `model.glb` by itself.

Use **打开模型** for a multi-file selection or **打开文件夹** for a folder.
For a legacy GLB without embedded metadata, select its JSON too. A pending JSON
or legacy GLB is retained until its partner is selected. New GLBs use embedded
metadata as authoritative, even if a sidecar JSON was also selected.
An invalid pair leaves the previous package available and reports the problem.
All model file reads remain local to the browser.

The optional real-data test runs when `BIM_TEST_PACKAGE_DIR` names a directory
containing `model.json` and `model.glb`. Without it, the real-data test is skipped;
the captured legacy-schema and malformed-package regressions still run.

Set `BIM_WRITER_TEST_GLB` to the synthetic GLB generated by the C# smoke executable
to also run the cross-language single-file regression.

