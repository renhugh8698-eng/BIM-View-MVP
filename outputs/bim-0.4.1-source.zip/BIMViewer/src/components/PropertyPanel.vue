<script setup lang="ts">
import { computed } from 'vue';
import type { BimElementRecord } from '../types/bim';

const props = defineProps<{
  element: BimElementRecord | null;
  isHidden: boolean;
  isIsolated: boolean;
}>();

defineEmits<{
  hide: [];
  isolate: [];
}>();

const parameterRows = computed(() => Object.entries(props.element?.parameters ?? {}).slice(0, 200));
</script>

<template>
  <div class="panel-title">构件属性</div>
  <div v-if="!element" class="empty-state">未选择构件</div>
  <div v-else class="properties">
    <div class="property-head">
      <h2>{{ element.family || element.name || element.category }}</h2>
      <p>{{ element.type || element.category }}</p>
      <div class="property-actions">
        <button type="button" @click="$emit('hide')">{{ isHidden ? '显示' : '隐藏' }}</button>
        <button type="button" @click="$emit('isolate')">{{ isIsolated ? '取消隔离' : '隔离' }}</button>
      </div>
    </div>

    <dl class="meta-list">
      <div>
        <dt>BIM ID</dt>
        <dd>{{ element.bimId }}</dd>
      </div>
      <div>
        <dt>Element ID</dt>
        <dd>{{ element.elementId }}</dd>
      </div>
      <div>
        <dt>Unique ID</dt>
        <dd>{{ element.uniqueId }}</dd>
      </div>
      <div>
        <dt>类别</dt>
        <dd>{{ element.category }}</dd>
      </div>
    </dl>

    <div class="parameter-table">
      <div v-for="[name, value] in parameterRows" :key="name" class="parameter-row">
        <span>{{ name }}</span>
        <strong>{{ value }}</strong>
      </div>
    </div>
  </div>
</template>
