<script setup lang="ts">
import type { BimTreeNode } from '../types/bim';
import { Eye, EyeOff, Focus } from 'lucide-vue-next';
import { ref, watch } from 'vue';

const props = withDefaults(defineProps<{
  nodes: BimTreeNode[];
  selectedId: string | null;
  hiddenIds: Set<string>;
  isolatedId: string | null;
  nested?: boolean;
  autoExpand?: boolean;
}>(), {
  nested: false,
  autoExpand: false,
});
const expanded = ref<Record<string, boolean>>({});
const isOpen = (id: string) => expanded.value[id] ?? props.autoExpand;
watch(() => props.autoExpand, () => { expanded.value = {}; });

const emit = defineEmits<{
  select: [id: string | null];
  toggleHidden: [id: string];
  isolate: [id: string];
}>();
</script>

<template>
  <div v-if="nodes.length === 0 && !nested" class="empty-state">暂无构件</div>
  <ul v-else class="tree-list">
    <li v-for="node in nodes" :key="node.id" class="tree-node">
      <details :open="isOpen(node.id)">
        <summary :class="{ category: node.kind === 'category', selected: selectedId === node.id }" @click.prevent="expanded[node.id] = !isOpen(node.id)">
          <button
            v-if="node.kind === 'element'"
            type="button"
            class="tree-label"
            :class="{ muted: hiddenIds.has(node.id), isolated: isolatedId === node.id || selectedId === node.id }"
            @click.stop="emit('select', node.id)"
          >
            {{ node.label }}
          </button>
          <span v-else>{{ node.label }}</span>
          <span v-if="node.kind === 'category'" class="count">{{ node.children.length }}</span>
          <span v-if="node.kind === 'element'" class="tree-actions">
            <button class="icon-button" type="button" :title="hiddenIds.has(node.id) ? '显示构件' : '隐藏构件'" @click.stop="emit('toggleHidden', node.id)">
              <EyeOff v-if="hiddenIds.has(node.id)" :size="14" /><Eye v-else :size="14" />
            </button>
            <button class="icon-button" type="button" title="隔离构件" :aria-pressed="isolatedId === node.id" @click.stop="emit('isolate', node.id)">
              <Focus :size="14" />
            </button>
          </span>
        </summary>
        <ModelTree
          v-if="node.children.length > 0 && isOpen(node.id)"
          :auto-expand="autoExpand"
          :nodes="node.children"
          :selected-id="selectedId"
          :hidden-ids="hiddenIds"
          :isolated-id="isolatedId"
          nested
          @select="emit('select', $event)"
          @toggle-hidden="emit('toggleHidden', $event)"
          @isolate="emit('isolate', $event)"
        />
      </details>
    </li>
  </ul>
</template>
