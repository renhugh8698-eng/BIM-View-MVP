export interface BimElementRecord {
  bimId: string;
  elementId: number;
  uniqueId: string;
  name: string;
  category: string;
  family: string;
  type: string;
  parameters: Record<string, string>;
}

export interface BimTreeNode {
  id: string;
  label: string;
  kind: 'category' | 'element';
  children: BimTreeNode[];
}

export interface BimPackage {
  schema: 'bim-mvp-package/v1';
  exportedAt: string;
  source: {
    revitVersion: string;
    title: string;
    path: string;
  };
  files: {
    glb: string;
  };
  elements: BimElementRecord[];
  tree: BimTreeNode[];
}
