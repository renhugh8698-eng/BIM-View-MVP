import { Vector3 } from 'three';
export type MeasureKind = 'distance' | 'angle';
export function measurement(kind: MeasureKind, points: Vector3[]) {
  if (points.length !== (kind === 'distance' ? 2 : 3) || points.some(p => ![p.x,p.y,p.z].every(Number.isFinite))) return null;
  const a = points[0].clone().sub(points[1]);
  if (a.length() < 1e-7) return null;
  if (kind === 'distance') return { value: a.length() * 1000, components: [Math.abs(a.x)*1000,Math.abs(a.y)*1000,Math.abs(a.z)*1000] };
  const b = points[2].clone().sub(points[1]);
  if (b.length() < 1e-7) return null;
  return { value: a.angleTo(b) * 180 / Math.PI, components: [] };
}
export const defaultSettings = { mode: 'material', edges: false, grid: false, exposure: 1, speed: 3 };
export function parseSettings(raw: string | null): typeof defaultSettings {
  try {
    const p = JSON.parse(raw ?? '{}');
    return { mode: ['material','category','white','xray'].includes(p.mode) ? p.mode : 'material',
      edges: p.edges === true, grid: p.grid === true,
      exposure: typeof p.exposure === 'number' && Number.isFinite(p.exposure) ? Math.max(.4,Math.min(1.8,p.exposure)) : 1,
      speed: typeof p.speed === 'number' && Number.isFinite(p.speed) ? Math.max(.2,Math.min(30,p.speed)) : 3 };
  } catch { return { ...defaultSettings }; }
}
