import type { BimTreeNode } from '../types/bim';
const palette = ['#349ba1', '#d58a48', '#7089cb', '#b65d80', '#8aa34c', '#a67cba', '#4c9dc0', '#c8a842'];
export function categoryColor(category: string): string {
  let hash = 0;
  for (const char of category) hash = ((hash * 31) + char.charCodeAt(0)) >>> 0;
  return palette[hash % palette.length];
}
export function filterTree(nodes: BimTreeNode[], query: string): BimTreeNode[] {
  const term = query.trim().toLocaleLowerCase();
  if (!term) return nodes;
  return nodes.flatMap(node => {
    if (`${node.label} ${node.id}`.toLocaleLowerCase().includes(term)) return [node];
    const children = filterTree(node.children, term);
    return children.length ? [{ ...node, children }] : [];
  });
}
export function clipConstant(min: number, max: number, percent: number): number {
  return min + (max - min) * Math.max(0, Math.min(100, percent)) / 100;
}
