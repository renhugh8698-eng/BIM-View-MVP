import type { Object3D } from 'three';
import type { BimElementRecord, BimPackage, BimTreeNode } from '../types/bim';

export function parseBimPackage(text: string): BimPackage {
  const parsed = object(JSON.parse(text));
  if (parsed.schema !== 'bim-mvp-package/v1') {
    throw new Error('Unsupported BIM package schema.');
  }
  if (!Array.isArray(parsed.elements) || !Array.isArray(parsed.tree)) {
    throw new Error('Invalid BIM package: missing elements or tree.');
  }
  const source = object(parsed.source);
  const files = object(parsed.files);
  const elements = parsed.elements.map((value): BimElementRecord => {
    const record = object(value);
    const read = (key: string) => record[key] ?? record[key[0].toUpperCase() + key.slice(1)];
    const elementId = read('elementId');
    if (!Number.isSafeInteger(elementId)) throw new Error('Invalid elementId.');
    const parameters = object(read('parameters'));
    if (Object.values(parameters).some(value => typeof value !== 'string')) {
      throw new Error('Invalid element parameters.');
    }
    return {
      bimId: string(read('bimId'), false), elementId: elementId as number,
      uniqueId: string(read('uniqueId'), false), name: string(read('name')),
      category: string(read('category')), family: string(read('family')),
      type: string(read('type')), parameters: parameters as Record<string, string>,
    };
  });
  const elementIds = new Set(elements.map(element => element.bimId));
  if (elementIds.size !== elements.length) throw new Error('Duplicate BIM element IDs.');
  const nodeIds = new Set<string>();
  const treeIds = new Set<string>();
  function readNode(value: unknown, depth = 0): BimTreeNode {
    if (depth > 64) throw new Error('Model tree is too deep.');
    const node = object(value);
    const id = string(node.id ?? node.Id, false);
    const label = string(node.label ?? node.Label);
    const kind = node.kind ?? node.Kind;
    const children = node.children ?? node.Children;
    if ((kind !== 'category' && kind !== 'element') || !Array.isArray(children) || nodeIds.has(id)) {
      throw new Error('Invalid or duplicate model tree node.');
    }
    nodeIds.add(id);
    if (kind === 'element') {
      if (!elementIds.has(id) || children.length) throw new Error('Model tree references an invalid element.');
      treeIds.add(id);
    }
    return { id, label, kind, children: children.map(child => readNode(child, depth + 1)) };
  }
  const tree = parsed.tree.map(node => readNode(node));
  if (treeIds.size !== elementIds.size) throw new Error('Model tree is missing elements.');
  return {
    schema: 'bim-mvp-package/v1', exportedAt: string(parsed.exportedAt),
    source: { title: string(source.title), path: string(source.path), revitVersion: string(source.revitVersion) },
    files: { glb: string(files.glb, false) }, elements, tree,
  };
}

function object(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Invalid BIM package object.');
  return value as Record<string, unknown>;
}

function string(value: unknown, allowEmpty = true): string {
  if (typeof value !== 'string' || (!allowEmpty && !value.trim())) throw new Error('Missing or invalid BIM package field.');
  return value;
}

export function readGlbJson(buffer: ArrayBuffer): Record<string, unknown> {
  const view = new DataView(buffer);
  if (view.byteLength < 20 || view.getUint32(0, true) !== 0x46546c67 ||
      view.getUint32(4, true) !== 2 || view.getUint32(8, true) !== view.byteLength ||
      view.getUint32(16, true) !== 0x4e4f534a) throw new Error('Invalid GLB 2.0 file.');
  const jsonLength = view.getUint32(12, true);
  if (jsonLength % 4 || 20 + jsonLength > view.byteLength) throw new Error('Invalid GLB JSON chunk.');
  const gltf = object(JSON.parse(new TextDecoder().decode(new Uint8Array(buffer, 20, jsonLength))));
  let offset = 20 + jsonLength;
  while (offset < buffer.byteLength) {
    if (offset + 8 > buffer.byteLength) throw new Error('Truncated GLB chunk.');
    const length = view.getUint32(offset, true);
    if (length % 4 || offset + 8 + length > buffer.byteLength) throw new Error('Invalid GLB chunk length.');
    offset += 8 + length;
  }
  return gltf;
}

export function embeddedBimPackage(buffer: ArrayBuffer): BimPackage | null {
  const gltf = readGlbJson(buffer);
  if (!gltf.extras) return null;
  const extras = object(gltf.extras);
  if (extras.bimPackage === undefined || extras.bimPackage === null) return null;
  const data = parseBimPackage(JSON.stringify(extras.bimPackage));
  validateGlbPair(buffer, data);
  return data;
}

export function validateGlbPair(buffer: ArrayBuffer, data: BimPackage): void {
  const gltf = readGlbJson(buffer);
  if (!Array.isArray(gltf.nodes)) throw new Error('GLB has no BIM nodes.');
  const ids = new Set<string>();
  for (const value of gltf.nodes) {
    const node = object(value);
    const extras = node.extras ? object(node.extras) : {};
    if (typeof extras.bimId === 'string') ids.add(extras.bimId);
  }
  if (ids.size !== data.elements.length || data.elements.some(element => !ids.has(element.bimId))) {
    throw new Error('GLB 与 JSON 的构件不匹配，请选择同一次导出的两个文件。');
  }
}

export function selectPackageFiles(files: File[]): { json?: File; glb?: File } {
  const json = files.filter(file => /\.json$/i.test(file.name));
  const glb = files.filter(file => /\.glb$/i.test(file.name));
  if (json.length > 1 || glb.length > 1) throw new Error('每次只能选择一份 JSON 和一份 GLB。');
  if (!json.length && !glb.length) throw new Error('未选择 JSON 或 GLB 文件。');
  return { json: json[0], glb: glb[0] };
}

export function indexElements(elements: BimElementRecord[]): Map<string, BimElementRecord> {
  return new Map(elements.map((element) => [element.bimId, element]));
}

export function findBimId(object: Object3D | null): string | null {
  let current: Object3D | null = object;
  while (current) {
    const bimId = current.userData?.bimId;
    if (typeof bimId === 'string' && bimId.length > 0) {
      return bimId;
    }
    current = current.parent;
  }
  return null;
}

export function collectElementIds(nodes: BimTreeNode[]): string[] {
  const ids: string[] = [];
  for (const node of nodes) {
    if (node.kind === 'element') {
      ids.push(node.id);
    }
    ids.push(...collectElementIds(node.children ?? []));
  }
  return ids;
}

export function nextHiddenSet(hidden: Set<string>, id: string): Set<string> {
  const next = new Set(hidden);
  if (next.has(id)) {
    next.delete(id);
  } else {
    next.add(id);
  }
  return next;
}
