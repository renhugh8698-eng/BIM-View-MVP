import { InstancedMesh, LOD, Mesh, type Material, type Object3D, type BufferGeometry } from 'three';

export class FrameSampler {
  private intervals: number[] = [];
  private costs: number[] = [];
  private previous: number | null = null;
  private lastDraw: number | null = null;
  reset() { this.intervals = []; this.costs = []; this.previous = null; this.lastDraw = null; }
  idle() { this.previous = null; }
  frame(now: number, cpuMs: number) {
    if (this.previous !== null && now > this.previous) this.intervals.push(now - this.previous);
    this.costs.push(Math.max(0, cpuMs));
    this.intervals = this.intervals.slice(-120); this.costs = this.costs.slice(-120);
    this.previous = now; this.lastDraw = now + Math.max(0,cpuMs);
  }
  snapshot(now: number) {
    const mean = (a: number[]) => a.length ? a.reduce((s, n) => s+n, 0) / a.length : null;
    const sorted = [...this.intervals].sort((a,b) => a-b);
    const avg = mean(this.intervals);
    return { idle: this.lastDraw === null || now - this.lastDraw > 500,
      fps: avg === null ? null : 1000 / avg, frameMs: avg,
      p95Ms: sorted.length ? sorted[Math.ceil(sorted.length * .95)-1] : null,
      cpuMs: mean(this.costs), samples: this.intervals.length,
      slowFrames: this.intervals.filter(n => n > 50).length, history: this.intervals.slice(-40) };
  }
}

export function inspectModel(root?: Object3D) {
  const geometries = new Set<BufferGeometry>(), materials = new Set<Material>(), arrays = new Set<ArrayBufferView>();
  const result = { meshes: 0, triangles: 0, uniqueGeometries: 0, materialObjects: 0, geometryBytes: 0,
    instancedBatches: 0, instances: 0, lodGroups: 0, lodLevels: 0 };
  root?.traverse(o => {
    if (o instanceof LOD) { result.lodGroups++; result.lodLevels += o.levels.length; }
    if (!(o instanceof Mesh)) return;
    result.meshes++;
    const count = o instanceof InstancedMesh ? o.count : 1;
    if (o instanceof InstancedMesh) { result.instancedBatches++; result.instances += count; arrays.add(o.instanceMatrix.array); if (o.instanceColor) arrays.add(o.instanceColor.array); }
    result.triangles += (o.geometry.index?.count ?? o.geometry.attributes.position?.count ?? 0) / 3 * count;
    geometries.add(o.geometry);
    for (const m of Array.isArray(o.material) ? o.material : [o.material]) materials.add(m);
  });
  for (const g of geometries) {
    if (g.index) arrays.add(g.index.array);
    for (const a of Object.values(g.attributes)) arrays.add('data' in a ? a.data.array : a.array);
  }
  result.uniqueGeometries = geometries.size; result.materialObjects = materials.size;
  result.geometryBytes = [...arrays].reduce((s,a) => s+a.byteLength, 0);
  return result;
}
export interface PerformanceSnapshot {
  timing: ReturnType<FrameSampler['snapshot']>;
  model: ReturnType<typeof inspectModel>;
  calls: number; triangles: number; lines: number; points: number;
  geometries: number; textures: number; programs: number;
  visibleMeshes: number; transparentMeshes: number; activeLods: string;
  width: number; height: number; pixelRatio: number; heapBytes: number | null;
  loadMs: number | null; pickMs: number | null; appearanceMs: number | null;
}
