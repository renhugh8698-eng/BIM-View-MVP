<script setup lang="ts">
import { computed, onBeforeUnmount, ref } from 'vue';
import ModelTree from './components/ModelTree.vue';
import ModelViewer from './components/ModelViewer.vue';
import PropertyPanel from './components/PropertyPanel.vue';
import { embeddedBimPackage, indexElements, nextHiddenSet, parseBimPackage, selectPackageFiles, validateGlbPair } from './lib/bimPackage';
import type { BimPackage } from './types/bim';
import { Box, FolderOpen, Folder, Eye, PanelLeft, PanelRight, Search } from 'lucide-vue-next';
import { filterTree } from './lib/viewerTools';

const bimPackage = ref<BimPackage | null>(null);
const modelUrl = ref<string | null>(null);
const selectedId = ref<string | null>(null);
const hiddenIds = ref<Set<string>>(new Set());
const isolatedId = ref<string | null>(null);
const loadError = ref<string | null>(null);
const loadStatus = ref('');
const activePanel = ref('model');
const treeOpen = ref(false);
const propertiesOpen = ref(false);
const query = ref('');
const filteredTree = computed(() => filterTree(bimPackage.value?.tree ?? [], query.value));
const pending = { json: undefined as File | undefined, glb: undefined as File | undefined };
let loadSequence = 0;

const elementsById = computed(() => indexElements(bimPackage.value?.elements ?? []));
const selectedElement = computed(() => (selectedId.value ? elementsById.value.get(selectedId.value) ?? null : null));

async function onFiles(event: Event) {
  const input = event.target as HTMLInputElement;
  const files = Array.from(input.files ?? []);
  input.value = '';
  if (!files.length) return;
  const sequence = ++loadSequence;
  try {
    const selected = selectPackageFiles(files);
    if (selected.json) pending.json = selected.json;
    if (selected.glb) pending.glb = selected.glb;
    loadError.value = null;
    if (!pending.glb) {
      loadStatus.value = 'JSON 已就绪，待选择 GLB';
      return;
    }
    const { json, glb } = pending;
    loadStatus.value = '正在校验模型…';
    const buffer = await glb.arrayBuffer();
    if (sequence !== loadSequence) return;
    let data = embeddedBimPackage(buffer);
    if (!data) {
      if (!json) {
        loadStatus.value = '此 GLB 未内嵌属性，待选择配套 JSON';
        return;
      }
      data = parseBimPackage(await json.text());
      if (sequence !== loadSequence) return;
      validateGlbPair(buffer, data);
    }
    const nextUrl = URL.createObjectURL(glb);
    const previousUrl = modelUrl.value;
    bimPackage.value = data;
    modelUrl.value = nextUrl;
    selectedId.value = null;
    hiddenIds.value = new Set();
    isolatedId.value = null;
    pending.json = undefined;
    pending.glb = undefined;
    loadStatus.value = '正在加载几何…';
    if (previousUrl) URL.revokeObjectURL(previousUrl);
  } catch (error) {
    if (sequence !== loadSequence) return;
    pending.json = undefined;
    pending.glb = undefined;
    loadStatus.value = '';
    loadError.value = error instanceof Error ? error.message : '模型加载失败。';
  }
}

onBeforeUnmount(() => {
  ++loadSequence;
  if (modelUrl.value) URL.revokeObjectURL(modelUrl.value);
});

function selectElement(id: string | null) {
  selectedId.value = id;
  if (id) propertiesOpen.value = true;
}

function toggleHidden(id: string) {
  hiddenIds.value = nextHiddenSet(hiddenIds.value, id);
  if (isolatedId.value === id) isolatedId.value = null;
}

function isolate(id: string) {
  isolatedId.value = isolatedId.value === id ? null : id;
  if (isolatedId.value && hiddenIds.value.has(id)) hiddenIds.value = nextHiddenSet(hiddenIds.value, id);
}

function resetVisibility() {
  hiddenIds.value = new Set();
  isolatedId.value = null;
}
</script>

<template>
  <main class="app-shell">
    <header class="topbar">
      <div>
        <h1><Box :size="23" /> BIM Viewer <small>WORKSPACE</small></h1>
        <p v-if="bimPackage">{{ bimPackage.source.title }} · {{ bimPackage.elements.length }} 个构件</p>
        <p v-else>未加载模型</p>
      </div>

      <div class="file-actions">
        <label class="file-button">
          <FolderOpen :size="16" /> 打开模型
          <input aria-label="打开模型" type="file" multiple accept=".json,.glb" @change="onFiles" />
        </label>
        <label class="file-button icon-button" title="打开文件夹">
          <Folder :size="18" />
          <input aria-label="打开文件夹" type="file" webkitdirectory multiple @change="onFiles" />
        </label>
        <button class="icon-button" type="button" title="显示全部" @click="resetVisibility"><Eye :size="18" /></button>
        <button class="icon-button desktop-toggle" title="构件面板" :aria-pressed="treeOpen" @click="treeOpen = !treeOpen"><PanelLeft :size="18" /></button>
        <button class="icon-button desktop-toggle" title="属性面板" :aria-pressed="propertiesOpen" @click="propertiesOpen = !propertiesOpen"><PanelRight :size="18" /></button>
      </div>
    </header>

    <section v-if="loadError" role="alert" class="error">{{ loadError }}</section>
    <div v-if="loadStatus" role="status" class="load-status">{{ loadStatus }}</div>

    <nav class="mobile-panels" aria-label="模型面板" role="tablist">
      <button role="tab" :aria-selected="activePanel === 'model'" @click="activePanel = 'model'">模型</button>
      <button role="tab" :aria-selected="activePanel === 'tree'" @click="activePanel = 'tree'">构件</button>
      <button role="tab" :aria-selected="activePanel === 'properties'" @click="activePanel = 'properties'">属性</button>
    </nav>
    <section class="workspace" :data-panel="activePanel" :class="{ 'tree-closed': !treeOpen, 'properties-closed': !propertiesOpen }">
      <aside class="tree-panel">
        <div class="panel-title">构件浏览 <span class="count">{{ bimPackage?.elements.length ?? 0 }}</span></div>
        <label class="tree-search"><Search :size="15" /><input v-model="query" aria-label="搜索构件" placeholder="搜索名称、类别或 ID" /></label>
        <ModelTree
          :nodes="filteredTree"
          :auto-expand="!!query.trim()"
          :selected-id="selectedId"
          :hidden-ids="hiddenIds"
          :isolated-id="isolatedId"
          @select="selectElement"
          @toggle-hidden="toggleHidden"
          @isolate="isolate"
        />
      </aside>

      <ModelViewer
        class="viewer-panel"
        :model-url="modelUrl"
        :selected-id="selectedId"
        :hidden-ids="hiddenIds"
        :isolated-id="isolatedId"
        :elements="bimPackage?.elements ?? []"
        @select="selectElement"
        @loaded="loadStatus = ''"
        @tree="treeOpen = !treeOpen; activePanel = 'tree'"
        @properties="propertiesOpen = !propertiesOpen; activePanel = 'properties'"
        @restore="resetVisibility"
        @error="loadError = $event; loadStatus = ''"
      />

      <aside class="property-panel">
        <PropertyPanel
          :element="selectedElement"
          :is-hidden="selectedId ? hiddenIds.has(selectedId) : false"
          :is-isolated="selectedId === isolatedId"
          @hide="selectedId && toggleHidden(selectedId)"
          @isolate="selectedId && isolate(selectedId)"
        />
      </aside>
    </section>
  </main>
</template>
