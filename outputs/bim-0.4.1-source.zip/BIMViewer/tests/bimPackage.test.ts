import { describe, expect, it } from 'vitest';
import { Object3D } from 'three';
import { collectElementIds, findBimId, indexElements, nextHiddenSet, parseBimPackage } from '../src/lib/bimPackage';
import type { BimPackage } from '../src/types/bim';

const sample: BimPackage = {
  schema: 'bim-mvp-package/v1',
  exportedAt: '2026-10-14T00:00:00.000Z',
  source: { revitVersion: '2020', title: 'sample', path: '' },
  files: { glb: 'model.glb' },
  elements: [
    { bimId: 'bim-a', elementId: 1, uniqueId: 'u1', name: 'Wall', category: 'Walls', family: 'Basic Wall', type: 'Generic', parameters: {} },
  ],
  tree: [
    { id: 'category:Walls', label: 'Walls', kind: 'category', children: [{ id: 'bim-a', label: 'Wall', kind: 'element', children: [] }] },
  ],
};

describe('bim package helpers', () => {
  it('parses and validates package schema', () => {
    expect(parseBimPackage(JSON.stringify(sample)).elements).toHaveLength(1);
    expect(() => parseBimPackage(JSON.stringify({ ...sample, schema: 'x' }))).toThrow(/Unsupported/);
  });

  it('indexes elements by stable bim id', () => {
    expect(indexElements(sample.elements).get('bim-a')?.category).toBe('Walls');
  });

  it('finds bim id through object parents', () => {
    const parent = new Object3D();
    parent.userData.bimId = 'bim-a';
    const child = new Object3D();
    parent.add(child);
    expect(findBimId(child)).toBe('bim-a');
  });

  it('collects tree element ids and toggles hidden state', () => {
    expect(collectElementIds(sample.tree)).toEqual(['bim-a']);
    expect(nextHiddenSet(new Set(), 'bim-a').has('bim-a')).toBe(true);
    expect(nextHiddenSet(new Set(['bim-a']), 'bim-a').has('bim-a')).toBe(false);
  });
});
