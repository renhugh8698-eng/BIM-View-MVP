import { describe, expect, it } from 'vitest';
import { Vector3 } from 'three';
import { measurement, parseSettings, defaultSettings } from '../src/lib/inspection';
describe('inspection measurements', () => {
  it('converts world meters to millimeters and reports axis magnitudes', () => {
    const m = measurement('distance',[new Vector3(1,2,3),new Vector3(4,6,3)])!;
    expect(m.value).toBe(5000); expect(m.components).toEqual([3000,4000,0]);
  });
  it('uses the middle point as the angle vertex', () => expect(measurement('angle',[new Vector3(1,0,0),new Vector3(),new Vector3(0,1,0)])?.value).toBe(90));
  it('rejects duplicate points and incomplete or nonfinite measurements', () => {
    expect(measurement('angle',[new Vector3(),new Vector3(),new Vector3(1,0,0)])).toBeNull();
    expect(measurement('distance',[new Vector3()])).toBeNull();
    expect(measurement('distance',[new Vector3(),new Vector3(Infinity,0,0)])).toBeNull();
  });
  it('handles a straight angle', () => expect(measurement('angle',[new Vector3(-1,0,0),new Vector3(),new Vector3(1,0,0)])?.value).toBe(180));
});
describe('display settings persistence', () => {
  it('falls back safely for corrupt or null storage', () => { expect(parseSettings('bad')).toEqual(defaultSettings); expect(parseSettings('null')).toEqual(defaultSettings); });
  it('clamps numeric inputs and validates modes and flags', () => { expect(parseSettings('{"exposure":100,"speed":-1,"mode":"invalid","edges":"yes"}')).toEqual({...defaultSettings,exposure:1.8,speed:.2}); });
  it('round trips supported settings', () => { const value = {...defaultSettings,mode:'category',grid:true,edges:true,speed:5}; expect(parseSettings(JSON.stringify(value))).toEqual(value); });
});
