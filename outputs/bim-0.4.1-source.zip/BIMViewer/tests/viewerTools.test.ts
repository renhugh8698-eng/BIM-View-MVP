import { describe, expect, it } from 'vitest';
import { categoryColor, clipConstant, filterTree } from '../src/lib/viewerTools';
import type { BimTreeNode } from '../src/types/bim';
const nodes: BimTreeNode[] = [{ id: 'walls', label: 'Walls', kind: 'category', children: [
  { id: '42', label: 'External wall', kind: 'element', children: [] },
  { id: '43', label: 'Internal wall', kind: 'element', children: [] },
] }];
describe('viewer tools', () => {
  it('uses deterministic category colors', () => { expect(categoryColor('Walls')).toBe(categoryColor('Walls')); expect(categoryColor('墙')).toMatch(/^#[0-9a-f]{6}$/); });
  it('retains tree parents and matches ids without mutating data', () => { expect(filterTree(nodes, '42')[0].children).toHaveLength(1); expect(nodes[0].children).toHaveLength(2); });
  it('matches category case-insensitively', () => expect(filterTree(nodes, ' WALLS ')[0].children).toHaveLength(2));
  it('handles empty and missing searches', () => { expect(filterTree(nodes, '')).toBe(nodes); expect(filterTree(nodes, 'missing')).toEqual([]); });
  it('clips across negative and positive coordinates', () => { expect(clipConstant(-10, 30, 50)).toBe(10); expect(clipConstant(-10, 30, -5)).toBe(-10); expect(clipConstant(-10, 30, 150)).toBe(30); });
});
