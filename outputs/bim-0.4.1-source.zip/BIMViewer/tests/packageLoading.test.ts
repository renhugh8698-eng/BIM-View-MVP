import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { embeddedBimPackage, parseBimPackage, selectPackageFiles, validateGlbPair, indexElements } from '../src/lib/bimPackage';

// Captured field names and identifiers from the user's Revit 2020 sample export.
const legacy = {
  schema: 'bim-mvp-package/v1', exportedAt: '2026-10-14T00:00:00Z',
  source: { revitVersion: '2020', title: 'RAC_basic_sample_project', path: '' },
  files: { glb: 'model.glb' },
  elements: [{ BimId: 'bim-93a1ae4b3619498e91be6ff9ca424062fc7d9ea7', ElementId: 176804,
    UniqueId: '203cff26-4c9d-4eb4-93e5-28d28a01f256-0002b2a4', Name: 'Generic 150mm',
    Category: '楼板', Family: '', Type: 'Generic 150mm', Parameters: { 标高: 'Level 1' } }],
  tree: [{ Id: 'category:楼板', Label: '楼板', Kind: 'category', Children: [
    { Id: 'bim-93a1ae4b3619498e91be6ff9ca424062fc7d9ea7', Label: 'Generic 150mm', Kind: 'element', Children: [] },
  ] }],
};

function glbWithId(id: string, metadata?: unknown): ArrayBuffer {
  const text = JSON.stringify({ nodes: [{ extras: { bimId: id } }], extras: { bimPackage: metadata } });
  const encoded = new TextEncoder().encode(text);
  const length = Math.ceil(encoded.length / 4) * 4;
  const buffer = new ArrayBuffer(20 + length);
  const view = new DataView(buffer);
  [0x46546c67, 2, buffer.byteLength, length, 0x4e4f534a].forEach((value, i) => view.setUint32(i * 4, value, true));
  new Uint8Array(buffer, 20).fill(32);
  new Uint8Array(buffer, 20).set(encoded);
  return buffer;
}

describe('export package compatibility', () => {
  it('loads a self-contained GLB and rejects corrupt embedded metadata', () => {
    const data = parseBimPackage(JSON.stringify(legacy));
    expect(embeddedBimPackage(glbWithId(data.elements[0].bimId, data))).toEqual(data);
    expect(embeddedBimPackage(glbWithId(data.elements[0].bimId))).toBeNull();
    expect(() => embeddedBimPackage(glbWithId('wrong-id', data))).toThrow(/不匹配/);
    expect(() => embeddedBimPackage(glbWithId(data.elements[0].bimId, { schema: 'bad' }))).toThrow();
  });
  it('loads legacy Revit field names into the tree and property index', () => {
    const parsed = parseBimPackage(JSON.stringify(legacy));
    const id = parsed.tree[0].children[0].id;
    expect(indexElements(parsed.elements).get(id)?.parameters['标高']).toBe('Level 1');
    expect(parsed.tree[0].children[0].children).toEqual([]);
    expect(parseBimPackage(JSON.stringify(parsed))).toEqual(parsed);
  });

  it('rejects incomplete records, duplicate IDs and invalid tree references', () => {
    const invalid = structuredClone(legacy);
    invalid.elements[0].BimId = '';
    expect(() => parseBimPackage(JSON.stringify(invalid))).toThrow();
    expect(() => parseBimPackage(JSON.stringify({ ...legacy, elements: [...legacy.elements, ...legacy.elements] }))).toThrow(/Duplicate/);
    expect(() => parseBimPackage(JSON.stringify({ ...legacy, tree: [] }))).toThrow(/missing/);
    const badTree = structuredClone(legacy);
    badTree.tree[0].Children[0].Id = 'unknown';
    expect(() => parseBimPackage(JSON.stringify(badTree))).toThrow(/invalid element/);
  });

  it('checks GLB integrity and rejects mismatched package IDs', () => {
    const data = parseBimPackage(JSON.stringify(legacy));
    expect(() => validateGlbPair(glbWithId(data.elements[0].bimId), data)).not.toThrow();
    expect(() => validateGlbPair(glbWithId('another-model'), data)).toThrow(/不匹配/);
    expect(() => validateGlbPair(new ArrayBuffer(8), data)).toThrow(/Invalid GLB/);
    const truncated = glbWithId(data.elements[0].bimId).slice(0, 24);
    expect(() => validateGlbPair(truncated, data)).toThrow(/Invalid GLB/);
  });

  it('accepts either order and individual selections, rejects ambiguous folders', () => {
    const json = { name: 'model.JSON' } as File;
    const glb = { name: 'model.glb' } as File;
    expect(selectPackageFiles([glb, json])).toEqual({ glb, json });
    expect(selectPackageFiles([json])).toEqual({ json, glb: undefined });
    expect(selectPackageFiles([glb])).toEqual({ json: undefined, glb });
    expect(() => selectPackageFiles([json, json, glb])).toThrow(/一份/);
  });
});

const actualDirectory = process.env.BIM_TEST_PACKAGE_DIR;
it.skipIf(!actualDirectory)('loads the actual Revit export and matches every GLB node', () => {
  const data = parseBimPackage(readFileSync(resolve(actualDirectory!, 'model.json'), 'utf8'));
  const bytes = readFileSync(resolve(actualDirectory!, 'model.glb'));
  validateGlbPair(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer, data);
  expect(data.elements.length).toBeGreaterThan(0);
  expect(indexElements(data.elements).size).toBe(data.elements.length);
});

const writerGlb = process.env.BIM_WRITER_TEST_GLB;
it.skipIf(!writerGlb)('reads the real C# writer output as a self-contained package', () => {
  const bytes = readFileSync(writerGlb!);
  const buffer = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
  const data = embeddedBimPackage(buffer);
  expect(data?.elements).toHaveLength(2);
  expect(data?.elements[1].bimId).toBe('bim-test-glass');
  expect(data?.elements[1].parameters.Fixture).toContain('Synthetic');
});
