import { describe, expect, it } from 'vitest';
import { BoxGeometry, Group, InstancedMesh, LOD, Mesh, MeshBasicMaterial } from 'three';
import { FrameSampler, inspectModel } from '../src/lib/performance';
describe('render sampling', () => {
  it('does not invent FPS without consecutive rendered frames', () => {
    const s = new FrameSampler(); s.frame(0,2);
    expect(s.snapshot(0).fps).toBeNull(); expect(s.snapshot(600).idle).toBe(true);
  });
  it('uses interval mean, percentile and CPU cost separately', () => {
    const s = new FrameSampler(); s.frame(0,2); s.frame(20,4); s.frame(80,6);
    const result = s.snapshot(80);
    expect(result.fps).toBe(25); expect(result.p95Ms).toBe(60); expect(result.slowFrames).toBe(1); expect(result.cpuMs).toBe(4);
  });
  it('excludes idle waits but preserves the last interaction sample', () => {
    const s = new FrameSampler(); s.frame(0,1); s.frame(20,1); s.idle(); s.frame(10000,1);
    expect(s.snapshot(10000).fps).toBe(50); expect(s.snapshot(10000).samples).toBe(1);
  });
  it('bounds history and resets between models', () => {
    const s = new FrameSampler(); for(let i=0;i<500;i++) s.frame(i*10,1);
    expect(s.snapshot(5000).samples).toBe(120); expect(s.snapshot(5000).history).toHaveLength(40);
    s.reset(); expect(s.snapshot(5000).samples).toBe(0); expect(s.snapshot(5000).cpuMs).toBeNull();
  });
  it('does not label an expensive in-progress render as idle', () => {
    const s = new FrameSampler(); s.frame(0,900); expect(s.snapshot(901).idle).toBe(false);
  });
});
describe('model inventory', () => {
  it('separates meshes, shared resources and real GPU instances', () => {
    const root = new Group(), geometry = new BoxGeometry(), material = new MeshBasicMaterial();
    root.add(new Mesh(geometry,material),new InstancedMesh(geometry,material,3));
    const result = inspectModel(root);
    expect(result.meshes).toBe(2); expect(result.uniqueGeometries).toBe(1); expect(result.materialObjects).toBe(1);
    expect(result.instances).toBe(3); expect(result.instancedBatches).toBe(1); expect(result.triangles).toBe(48);
    expect(result.geometryBytes).toBe(1032); geometry.dispose(); material.dispose();
  });
  it('counts actual LOD groups instead of inventing levels', () => {
    const root = new Group(), lod = new LOD(); lod.addLevel(new Group(),0); lod.addLevel(new Group(),10); root.add(lod);
    expect(inspectModel(root).lodGroups).toBe(1); expect(inspectModel(root).lodLevels).toBe(2); expect(inspectModel().lodGroups).toBe(0);
  });
});
