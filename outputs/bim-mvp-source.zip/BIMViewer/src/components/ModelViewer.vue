<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { Box3, BufferGeometry, Group, Line, Points, PointsMaterial, Color, DirectionalLight, EdgesGeometry, GridHelper, HemisphereLight, LineBasicMaterial,
  LineSegments, Material, Mesh, MeshStandardMaterial, MOUSE, Object3D, PerspectiveCamera, Plane,
  PMREMGenerator, Raycaster, Scene, SRGBColorSpace, TOUCH, Vector2, Vector3, WebGLRenderer, NeutralToneMapping } from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { FlyControls } from 'three/examples/jsm/controls/FlyControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { Box, Focus, Hand, Home, Orbit, Scissors, X, Ruler, Footprints, Settings, Camera, Maximize, Minimize, Trash2, Undo2, PanelLeft, PanelRight, Eye } from 'lucide-vue-next';
import { measurement, parseSettings, defaultSettings, type MeasureKind } from '../lib/inspection';
import { findBimId } from '../lib/bimPackage';
import { categoryColor, clipConstant } from '../lib/viewerTools';
import type { BimElementRecord } from '../types/bim';

const props = defineProps<{ modelUrl: string | null; selectedId: string | null; hiddenIds: Set<string>;
  isolatedId: string | null; elements: BimElementRecord[] }>();
const emit = defineEmits<{ select: [id: string | null]; error: [message: string]; loaded: []; tree: []; properties: []; restore: [] }>();
const rootHost = ref<HTMLDivElement | null>(null);
let saved = { ...defaultSettings };
try { saved = parseSettings(localStorage.getItem('bim-viewer-settings-v1')); } catch { /* Storage can be unavailable in private contexts. */ }
const canvasHost = ref<HTMLDivElement | null>(null);
const mode = ref(saved.mode), pan = ref(false), edges = ref(saved.edges), showGrid = ref(saved.grid), clipping = ref(false);
const clipAxis = ref<'x' | 'y' | 'z'>('y'), clipPosition = ref(65), exposure = ref(saved.exposure);
const settingsOpen = ref(false), measureOpen = ref(false), roaming = ref(false), speed = ref(saved.speed), fullscreen = ref(false);
const measureKind = ref<MeasureKind>('distance'), pendingPoints = ref<Vector3[]>([]), notice = ref('');
type Measurement = { id: number; kind: MeasureKind; points: Vector3[]; value: number; components: number[] };
const measures = ref<Measurement[]>([]);
const labels = ref<{ id: number; text: string; x: number; y: number }[]>([]);
const annotationGroup = new Group();
let measureId = 0, fly: FlyControls | undefined, lastTime = 0;
const materialCount = ref(0), triangleCount = ref(0), ready = ref(false);
const categories = computed(() => [...new Set(props.elements.map(e => e.category))].sort());
const scene = new Scene();
scene.background = new Color('#e6eaeb');
const camera = new PerspectiveCamera(45, 1, .01, 10000);
const raycaster = new Raycaster(), pointer = new Vector2(), bounds = new Box3();
const clipPlane = new Plane(new Vector3(0, -1, 0), 0);
const meshes = new Map<string, Mesh[]>();
const originals = new Map<Material, { color: Color; opacity: number; transparent: boolean; depthWrite: boolean; emissive: Color; intensity: number }>();
let renderer: WebGLRenderer | undefined, controls: OrbitControls | undefined, model: Object3D | undefined;
let frame = 0, sequence = 0, dirty = true;
let resizeObserver: ResizeObserver | undefined;
let environment: ReturnType<PMREMGenerator['fromScene']> | undefined;
let down = { x: 0, y: 0 };
const grid = new GridHelper(10, 20, 0xa9b6b9, 0xcbd4d6);
grid.visible = saved.grid;
scene.add(grid, annotationGroup, new HemisphereLight(0xffffff, 0x899599, 1.15));
const sun = new DirectionalLight(0xffffff, 2);
sun.position.set(10, 18, 9);
scene.add(sun);
function sine(aspect = camera.aspect) {
  const fov = camera.fov * Math.PI / 360;
  return Math.sin(Math.min(fov, Math.atan(Math.tan(fov) * aspect)));
}
function resize() {
  if (!canvasHost.value || !renderer) return;
  const { clientWidth: w, clientHeight: h } = canvasHost.value;
  if (!w || !h) return;
  const aspect = w / h;
  if (controls && model && !roaming.value) camera.position.sub(controls.target).multiplyScalar(sine() / sine(aspect)).add(controls.target);
  camera.aspect = aspect; camera.updateProjectionMatrix(); renderer.setSize(w, h); dirty = true;
}
function fit(box: Box3) {
  if (box.isEmpty() || !controls) return;
  const radius = Math.max(box.getSize(new Vector3()).length() / 2, .01);
  const direction = camera.position.clone().sub(controls.target).normalize();
  if (!direction.lengthSq()) direction.set(1, .8, 1).normalize();
  box.getCenter(controls.target);
  camera.position.copy(controls.target).addScaledVector(direction, radius / sine() * 1.12);
  const whole = Math.max(bounds.getSize(new Vector3()).length(), radius * 2);
  camera.near = Math.max(whole / 10000, .001); camera.far = Math.max(whole * 100, 100);
  controls.minDistance = Math.max(whole / 10000, .001); controls.maxDistance = whole * 30;
  camera.updateProjectionMatrix(); controls.update(); dirty = true;
}
function home() {
  setRoaming(false);
  if (!controls) return;
  camera.position.copy(controls.target).add(new Vector3(1, .8, 1)); fit(bounds);
}
function focusSelected() {
  if (measureOpen.value) return;
  setRoaming(false);
  const box = new Box3();
  for (const mesh of meshes.get(props.selectedId ?? '') ?? []) if (mesh.visible) box.expandByObject(mesh);
  fit(box);
}
function direction(view: string) {
  setRoaming(false);
  if (!controls) return;
  const offset = view === 'top' ? new Vector3(0, 1, .0001) : view === 'front' ? new Vector3(0, 0, 1) : new Vector3(1, 0, 0);
  camera.position.copy(controls.target).add(offset); fit(bounds);
}
function dispose(root: Object3D) {
  const materials = new Set<Material>();
  root.traverse(o => {
    if (o instanceof Mesh || o instanceof LineSegments || o instanceof Line || o instanceof Points) {
      o.geometry.dispose();
      for (const m of Array.isArray(o.material) ? o.material : [o.material]) materials.add(m);
    }
  });
  materials.forEach(m => m.dispose());
}
function load(url: string) {
  setRoaming(false); measures.value = []; pendingPoints.value = []; rebuildAnnotations(); notice.value = '';
  const current = ++sequence; ready.value = false;
  if (model) { scene.remove(model); dispose(model); model = undefined; }
  meshes.clear(); originals.clear(); bounds.makeEmpty(); clipping.value = false; clipPosition.value = 65; dirty = true;
  new GLTFLoader().load(url, gltf => {
    if (current !== sequence) { dispose(gltf.scene); return; }
    model = gltf.scene;
    const sourceMaterials = new Set<Material>(); let triangles = 0;
    model.traverse(o => {
      if (!(o instanceof Mesh)) return;
      const id = findBimId(o); if (!id) return;
      o.userData.bimId = id;
      const clone = (m: Material) => {
        sourceMaterials.add(m); const next = m.clone();
        if (next instanceof MeshStandardMaterial) {
          next.envMapIntensity = .65;
          if (next.transparent) next.depthWrite = false;
          originals.set(next, { color: next.color.clone(), opacity: next.opacity, transparent: next.transparent,
            depthWrite: next.depthWrite, emissive: next.emissive.clone(), intensity: next.emissiveIntensity });
        }
        return next;
      };
      o.material = Array.isArray(o.material) ? o.material.map(clone) : clone(o.material);
      meshes.set(id, [...(meshes.get(id) ?? []), o]);
      triangles += (o.geometry.index?.count ?? o.geometry.attributes.position.count) / 3;
    });
    materialCount.value = sourceMaterials.size; triangleCount.value = Math.round(triangles);
    sourceMaterials.forEach(m => m.dispose()); scene.add(model); bounds.setFromObject(model);
    const center = bounds.getCenter(new Vector3()), size = Math.max(bounds.getSize(new Vector3()).length(), 1);
    grid.scale.setScalar(size / 8); grid.position.set(center.x, bounds.min.y - size * .001, center.z);
    ready.value = true; home(); applyAppearance(); applyVisibility(); emit('loaded');
  }, undefined, e => { if (current === sequence) emit('error', e instanceof Error ? e.message : '模型加载失败'); });
}
function applyVisibility() {
  for (const [id, list] of meshes) for (const mesh of list)
    mesh.visible = !props.hiddenIds.has(id) && (!props.isolatedId || props.isolatedId === id);
  dirty = true;
}
function applyAppearance() {
  const records = new Map(props.elements.map(e => [e.bimId, e]));
  for (const [id, list] of meshes) for (const mesh of list) {
    for (const m of Array.isArray(mesh.material) ? mesh.material : [mesh.material]) {
      if (!(m instanceof MeshStandardMaterial)) continue;
      const original = originals.get(m)!; m.color.copy(original.color);
      if (mode.value === 'category') m.color.set(categoryColor(records.get(id)?.category ?? ''));
      if (mode.value === 'white') m.color.set('#e2e5e5');
      m.opacity = mode.value === 'xray' ? .18 : original.opacity;
      m.transparent = mode.value === 'xray' || original.transparent;
      m.depthWrite = mode.value === 'xray' ? false : original.depthWrite;
      m.emissive.copy(original.emissive); m.emissiveIntensity = original.intensity;
      if (id === props.selectedId) { m.emissive.set('#18a8a0'); m.emissiveIntensity = .5; }
      m.clippingPlanes = clipping.value ? [clipPlane] : []; m.needsUpdate = true;
    }
    let outline = mesh.children.find(child => child.userData.outline) as LineSegments | undefined;
    if (edges.value && !outline) {
      outline = new LineSegments(new EdgesGeometry(mesh.geometry, 30), new LineBasicMaterial({ color: 0x49595c, transparent: true, opacity: .45 }));
      outline.userData.outline = true; mesh.add(outline);
    }
    if (outline) {
      outline.visible = edges.value;
      const mat = outline.material as LineBasicMaterial;
      mat.clippingPlanes = clipping.value ? [clipPlane] : []; mat.needsUpdate = true;
    }
  }
  updateClip(); dirty = true;
}
function updateClip() {
  const axis = clipAxis.value;
  clipPlane.normal.set(axis === 'x' ? -1 : 0, axis === 'y' ? -1 : 0, axis === 'z' ? -1 : 0);
  clipPlane.constant = bounds.isEmpty() ? 0 : clipConstant(bounds.min[axis], bounds.max[axis], clipPosition.value); dirty = true;
}
function pick(event: MouseEvent) {
  if (roaming.value || event.button !== 0) return;
  if (Math.hypot(event.clientX - down.x, event.clientY - down.y) > 5 || !canvasHost.value || !model) return;
  const rect = canvasHost.value.getBoundingClientRect();
  pointer.set((event.clientX - rect.left) / rect.width * 2 - 1, -(event.clientY - rect.top) / rect.height * 2 + 1);
  raycaster.setFromCamera(pointer, camera);
  const hit = raycaster.intersectObjects([...meshes.values()].flat(), false)
    .find(h => h.object.visible && (!clipping.value || clipPlane.distanceToPoint(h.point) >= 0));
  if (measureOpen.value) {
    if (!hit) return;
    pendingPoints.value.push(hit.point.clone());
    const needed = measureKind.value === 'distance' ? 2 : 3;
    if (pendingPoints.value.length === needed) {
      const result = measurement(measureKind.value, pendingPoints.value);
      if (result) { measures.value.push({ id: ++measureId, kind: measureKind.value, points: [...pendingPoints.value], ...result }); notice.value = ''; }
      else notice.value = '测量点重合，请重新选择。';
      pendingPoints.value = [];
    }
    rebuildAnnotations(); return;
  }
  emit('select', findBimId(hit?.object ?? null));
}
function formatMeasure(m: {kind: MeasureKind; value: number}) { return `${m.value.toFixed(m.kind === 'angle' ? 2 : 1)} ${m.kind === 'angle' ? '°' : 'mm'}`; }
function rebuildAnnotations() {
  dispose(annotationGroup); annotationGroup.clear();
  const sets = [...measures.value.map(m => m.points), pendingPoints.value];
  for (const points of sets) {
    if (!points.length) continue;
    const geometry = new BufferGeometry().setFromPoints(points);
    const dots = new Points(geometry, new PointsMaterial({ color: 0xf5a623, size: 8, sizeAttenuation: false, depthTest: false }));
    dots.renderOrder = 1000; annotationGroup.add(dots);
    if (points.length > 1) {
      const line = new Line(geometry.clone(), new LineBasicMaterial({ color: 0xe49012, depthTest: false }));
      line.renderOrder = 999; annotationGroup.add(line);
    }
  }
  dirty = true;
}
function projectLabels() {
  if (!canvasHost.value) return;
  const w = canvasHost.value.clientWidth, h = canvasHost.value.clientHeight;
  labels.value = measures.value.flatMap(m => {
    const p = m.kind === 'angle' ? m.points[1].clone() : m.points[0].clone().lerp(m.points[1], .5);
    p.project(camera);
    return p.z < -1 || p.z > 1 || Math.abs(p.x) > 1 || Math.abs(p.y) > 1 ? [] : [{ id: m.id, text: formatMeasure(m), x: (p.x+1)*w/2, y: (1-p.y)*h/2 }];
  });
}
function removeMeasure(id: number) { measures.value = measures.value.filter(m => m.id !== id); rebuildAnnotations(); }
function clearMeasures() { measures.value = []; pendingPoints.value = []; rebuildAnnotations(); }
function toggleMeasure() {
  measureOpen.value = !measureOpen.value;
  setRoaming(false); settingsOpen.value = false; pendingPoints.value = []; rebuildAnnotations();
}
function stopFly() { fly?.dispose(); fly = undefined; }
function startFly() {
  if (!roaming.value || !renderer || fly) return;
  fly = new FlyControls(camera, renderer.domElement); fly.dragToLook = true; fly.rollSpeed = .6;
  fly.addEventListener('change', () => { dirty = true; });
}
function setRoaming(value: boolean) {
  const wasRoaming = roaming.value;
  stopFly(); roaming.value = value;
  if (!controls) return;
  controls.enabled = !value;
  if (value) {
    measureOpen.value = false; settingsOpen.value = false; pendingPoints.value = []; rebuildAnnotations();
    renderer?.domElement.focus(); startFly();
  } else if (wasRoaming) {
    const direction = camera.getWorldDirection(new Vector3());
    controls.target.copy(camera.position).addScaledVector(direction, Math.max(bounds.getSize(new Vector3()).length() / 10, 1));
    controls.update(); dirty = true;
  }
}
function onKey(event: KeyboardEvent) {
  if (event.key === 'Escape') { setRoaming(false); measureOpen.value = false; pendingPoints.value = []; rebuildAnnotations(); }
}
async function toggleFullscreen() {
  try {
    if (document.fullscreenElement) await document.exitFullscreen();
    else await rootHost.value?.requestFullscreen();
  } catch { notice.value = '当前浏览器不允许全屏。'; }
}
function fullChanged() { fullscreen.value = document.fullscreenElement === rootHost.value; resize(); }
async function openSidePanel(panel: 'tree' | 'properties') {
  if (document.fullscreenElement) {
    try { await document.exitFullscreen(); } catch { notice.value = '请先退出全屏再打开侧栏。'; return; }
  }
  if (panel === 'tree') emit('tree'); else emit('properties');
}
function screenshot() {
  if (!renderer || !canvasHost.value) return;
  renderer.render(scene,camera); projectLabels();
  const output = document.createElement('canvas'); output.width = renderer.domElement.width; output.height = renderer.domElement.height;
  const ctx = output.getContext('2d'); if (!ctx) return;
  ctx.drawImage(renderer.domElement,0,0);
  const scale = output.width / canvasHost.value.clientWidth;
  ctx.scale(scale,scale); ctx.font = '12px sans-serif';
  for (const label of labels.value) { const width = ctx.measureText(label.text).width; ctx.fillStyle = '#fff'; ctx.fillRect(label.x-width/2-4,label.y-20,width+8,20); ctx.fillStyle = '#6a4208'; ctx.fillText(label.text,label.x-width/2,label.y-6); }
  output.toBlob(blob => { if (!blob) { notice.value = '截图生成失败'; return; } const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `BIM-view-${Date.now()}.png`; a.click(); setTimeout(() => URL.revokeObjectURL(url),1000); },'image/png');
}
function resetSettings() { mode.value = 'material'; edges.value = false; showGrid.value = false; exposure.value = 1; speed.value = 3; }
function tick(time = 0) {
  const delta = Math.min(Math.max((time-lastTime)/1000,0),.05); lastTime = time;
  if (fly) { fly.movementSpeed = speed.value; fly.update(delta); }
  const changed = !roaming.value && controls?.update();
  if (dirty || changed) { renderer?.render(scene, camera); projectLabels(); dirty = false; }
  frame = requestAnimationFrame(tick);
}
onMounted(() => {
  if (!canvasHost.value) return;
  renderer = new WebGLRenderer({ antialias: true }); renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.outputColorSpace = SRGBColorSpace; renderer.toneMapping = NeutralToneMapping; renderer.localClippingEnabled = true;
  renderer.toneMappingExposure = exposure.value;
  renderer.domElement.tabIndex = 0;
  renderer.domElement.setAttribute('aria-label','三维模型画布');
  renderer.domElement.addEventListener('focus',startFly);
  renderer.domElement.addEventListener('blur',stopFly);
  window.addEventListener('blur',stopFly);
  window.addEventListener('keydown',onKey);
  document.addEventListener('fullscreenchange',fullChanged);
  canvasHost.value.appendChild(renderer.domElement);
  const pmrem = new PMREMGenerator(renderer), room = new RoomEnvironment();
  environment = pmrem.fromScene(room, .04); scene.environment = environment.texture;
  room.dispose(); pmrem.dispose();
  controls = new OrbitControls(camera, renderer.domElement); controls.enableDamping = true; controls.dampingFactor = .12;
  controls.addEventListener('change', () => { dirty = true; });
  resizeObserver = new ResizeObserver(resize); resizeObserver.observe(canvasHost.value); resize();
  if (props.modelUrl) load(props.modelUrl); tick();
});
onBeforeUnmount(() => {
  stopFly(); dispose(annotationGroup);
  window.removeEventListener('blur',stopFly); window.removeEventListener('keydown',onKey); document.removeEventListener('fullscreenchange',fullChanged);
  ++sequence; cancelAnimationFrame(frame); resizeObserver?.disconnect(); controls?.dispose();
  if (model) dispose(model);
  dispose(grid); environment?.dispose(); renderer?.dispose();
});
watch(() => props.modelUrl, url => { if (url) load(url); });
watch(() => [props.hiddenIds, props.isolatedId], applyVisibility, { deep: true });
watch([mode, edges, clipping, () => props.selectedId], applyAppearance);
watch([clipAxis, clipPosition], updateClip);
watch(showGrid, value => { grid.visible = value; dirty = true; });
watch(exposure, value => { if (renderer) renderer.toneMappingExposure = value; dirty = true; });
watch(pan, value => { if (controls) { controls.mouseButtons.LEFT = value ? MOUSE.PAN : MOUSE.ROTATE; controls.touches.ONE = value ? TOUCH.PAN : TOUCH.ROTATE; } });
watch(measureKind, () => { pendingPoints.value = []; rebuildAnnotations(); notice.value = ''; });
watch([mode,edges,showGrid,exposure,speed], () => {
  try { localStorage.setItem('bim-viewer-settings-v1',JSON.stringify({mode:mode.value,edges:edges.value,grid:showGrid.value,exposure:exposure.value,speed:speed.value})); } catch { /* Keep the viewer usable without persistence. */ }
});
</script>

<template>
  <div ref="rootHost" class="model-canvas" :class="{ 'is-measuring': measureOpen }">
    <div ref="canvasHost" class="canvas-surface" @pointerdown="down = { x: $event.clientX, y: $event.clientY }; renderer?.domElement.focus(); startFly()" @click="pick" @dblclick="focusSelected" />
    <div v-if="!modelUrl" class="viewer-empty"><Box :size="44" /><strong>未加载模型</strong></div>
    <div v-for="label in labels" :key="label.id" class="measurement-label" :style="{ left: `${label.x}px`, top: `${label.y}px` }">{{ label.text }}</div>
    <div v-if="notice" role="status" class="viewer-notice">{{ notice }}<button title="关闭提示" class="icon-button" @click="notice = ''"><X :size="14" /></button></div>
    <section v-if="settingsOpen" class="inspection-panel settings-panel" aria-label="显示设置">
      <header>显示设置<button class="icon-button" title="关闭设置" @click="settingsOpen = false"><X :size="16" /></button></header>
      <label>显示模式
      <select v-model="mode" aria-label="显示模式"><option value="material">原始材质</option><option value="category">分类着色</option><option value="white">白模</option><option value="xray">透视</option></select>
      </label>
      <label>曝光 <input v-model.number="exposure" aria-label="曝光" type="range" min="0.4" max="1.8" step="0.05" /><output>{{ exposure.toFixed(2) }}</output></label>
      <label>构件边线<input v-model="edges" type="checkbox" /></label>
      <label>地面网格<input v-model="showGrid" type="checkbox" /></label>
      <button @click="resetSettings">恢复默认设置</button>
    </section>
    <section v-if="measureOpen" class="inspection-panel measure-panel" aria-label="测量面板">
      <header>测量<button class="icon-button" title="关闭测量" @click="toggleMeasure"><X :size="16" /></button></header>
      <div class="segmented" role="group" aria-label="测量类型">
        <button :aria-pressed="measureKind === 'distance'" @click="measureKind = 'distance'">距离</button>
        <button :aria-pressed="measureKind === 'angle'" @click="measureKind = 'angle'">角度</button>
      </div>
      <div class="measure-progress"><span>已选 {{ pendingPoints.length }} / {{ measureKind === 'distance' ? 2 : 3 }} 点</span>
        <button class="icon-button" title="撤销测量点" :disabled="!pendingPoints.length" @click="pendingPoints.pop(); rebuildAnnotations()"><Undo2 :size="16" /></button>
        <button class="icon-button" title="清除全部测量" :disabled="!measures.length && !pendingPoints.length" @click="clearMeasures"><Trash2 :size="16" /></button>
      </div>
      <div class="measurement-results">
        <div v-for="m in measures" :key="m.id" class="measurement-result">
          <div><span>{{ m.kind === 'distance' ? '距离' : '角度' }} {{ m.id }}</span><strong>{{ formatMeasure(m) }}</strong><button class="icon-button" :title="`删除测量 ${m.id}`" @click="removeMeasure(m.id)"><Trash2 :size="14" /></button></div>
          <dl v-if="m.kind === 'distance'"><template v-for="(value, index) in m.components" :key="index"><dt>{{ ['X','Y','Z'][index] }}</dt><dd>{{ value.toFixed(1) }} mm</dd></template></dl>
        </div>
      </div>
    </section>
    <section v-if="roaming" class="inspection-panel roam-panel" aria-label="漫游设置">
      <header>自由漫游<button class="icon-button" title="退出漫游" @click="setRoaming(false)"><X :size="16" /></button></header>
      <label>速度<input v-model.number="speed" aria-label="漫游速度" type="range" min="0.2" max="30" step="0.2" /><output>{{ speed.toFixed(1) }} m/s</output></label>
    </section>
    <div class="view-directions" aria-label="视角"><button title="俯视" @click="direction('top')">顶</button><button title="正视" @click="direction('front')">前</button><button title="右视" @click="direction('right')">右</button></div>
    <div v-if="clipping" class="clip-controls">
      <Scissors :size="16" /><select v-model="clipAxis" aria-label="剖切轴"><option value="x">X</option><option value="y">Y（高度）</option><option value="z">Z</option></select>
      <input v-model.number="clipPosition" aria-label="剖切位置" type="range" min="0" max="100" step="1" />
      <output>{{ clipPosition }}%</output><button class="icon-button" title="关闭剖切" @click="clipping = false"><X :size="16" /></button>
    </div>
    <div v-if="mode === 'category'" class="category-legend"><div v-for="category in categories" :key="category"><i :style="{ background: categoryColor(category) }" />{{ category }}</div></div>
    <div class="viewer-toolbar" role="toolbar" aria-label="模型工具">
      <button class="icon-button" title="模型树" @click="openSidePanel('tree')"><PanelLeft :size="19" /></button>
      <button class="icon-button" title="全模型居中" :disabled="!ready" @click="home"><Home :size="19" /></button>
      <button class="icon-button" title="定位选中构件" :disabled="!selectedId || !ready" @click="focusSelected"><Focus :size="19" /></button><span class="tool-divider" />
      <button class="icon-button" title="旋转" :aria-pressed="!pan && !roaming" @click="setRoaming(false); pan = false"><Orbit :size="19" /></button>
      <button class="icon-button" title="平移" :aria-pressed="pan && !roaming" @click="setRoaming(false); pan = true"><Hand :size="19" /></button><span class="tool-divider" />
      <button class="icon-button" title="测量" :aria-pressed="measureOpen" :disabled="!ready" @click="toggleMeasure"><Ruler :size="19" /></button>
      <button class="icon-button" title="剖切" :aria-pressed="clipping" :disabled="!ready" @click="clipping = !clipping"><Scissors :size="19" /></button>
      <button class="icon-button" title="自由漫游：WASD 移动，拖动鼠标转向，R/F 升降，Esc 退出" aria-label="自由漫游" :aria-pressed="roaming" :disabled="!ready" @click="setRoaming(!roaming)"><Footprints :size="19" /></button>
      <button class="icon-button" title="构件属性" @click="openSidePanel('properties')"><PanelRight :size="19" /></button>
      <button class="icon-button" title="恢复全部可见" @click="emit('restore')"><Eye :size="19" /></button><span class="tool-divider" />
      <button class="icon-button" title="设置" :aria-pressed="settingsOpen" @click="settingsOpen = !settingsOpen; measureOpen = false; pendingPoints = []; rebuildAnnotations(); setRoaming(false)"><Settings :size="19" /></button>
      <button class="icon-button" title="下载截图" :disabled="!ready" @click="screenshot"><Camera :size="19" /></button>
      <button class="icon-button" :title="fullscreen ? '退出全屏' : '全屏'" @click="toggleFullscreen"><Minimize v-if="fullscreen" :size="19" /><Maximize v-else :size="19" /></button>
    </div>
    <div v-if="ready" class="scene-stats">{{ materialCount }} 材质 · {{ triangleCount.toLocaleString() }} 三角形</div>
  </div>
</template>
